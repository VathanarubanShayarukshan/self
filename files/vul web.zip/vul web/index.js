const express = require('express');
const { exec } = require('child_process');
const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// மாதிரி தரவுத்தளம் (JSON Object ஆக குறியீட்டிற்குள்ளேயே உள்ளது)
const db = {
  users: [
    {"id": 1001, "username": "admin", "password": "secureadmin2026", "balance": 50000},
    {"id": 1002, "username": "kumar", "password": "kumarpassword", "balance": 4820750}
  ],
  products: [
    {"id": "wealth_plan", "name": "Premium Wealth Plan", "price": 50000}
  ]
};

// பொதுவான வடிவமைப்பு (CSS Style)
const headerHTML = `
<!DOCTYPE html>
<html lang="ta">
<head>
    <meta charset="UTF-8">
    <title>Cyber Bank Lab</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f4f7f6; color: #333; }
        .container { max-width: 700px; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); margin: auto; }
        h1, h2 { color: #0056b3; }
        .nav-links a { display: inline-block; margin-right: 15px; color: #007bff; text-decoration: none; font-weight: bold; }
        .nav-links a:hover { text-decoration: underline; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="password"], select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; box-sizing: border-box; }
        button { background-color: #28a745; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
        button:hover { background-color: #218838; }
        .result-box { background: #e9ecef; padding: 15px; border-radius: 5px; margin-top: 20px; font-family: monospace; white-space: pre-wrap; word-wrap: break-word; }
    </style>
</head>
<body>
<div class="container">
    <div class="nav-links">
        <a href="/">🏠 முதன்மைப் பக்கம்</a> | 
        <a href="/sqli">1. SQLi</a> | 
        <a href="/xss">2. XSS</a> | 
        <a href="/idor">3. IDOR</a> | 
        <a href="/tampering">4. Price Tampering</a> | 
        <a href="/cmd">5. RCE</a> | 
        <a href="/jwt">6. JWT</a> | 
        <a href="/ssrf">7. SSRF</a>
    </div>
    <hr>
`;

const footerHTML = `
</div>
</body>
</html>
`;

// 1. முகப்புப் பக்கம் (Home Page)
app.get('/', (req, res) => {
    let html = `${headerHTML}
        <h1>🏦 Cyber Bank - பக் பவுண்டி சோதனை தளம்</h1>
        <p>சைபர் நண்பன் வீடியோவில் காட்டியவாறு, இணையதள தாக்குதல்களைச் சோதித்துப் பார்க்க பிரத்யேகமாக உருவாக்கப்பட்ட தளம்.</p>
        <h3>மேலே உள்ள மெனுவில் ஏதேனும் ஒரு தாக்குதலைத் தேர்ந்தெடுத்து சோதிக்கவும்.</h3>
    ${footerHTML}`;
    res.send(html);
});

// 2. SQL Injection பக்கம்
app.get('/sqli', (req, res) => {
    let html = `${headerHTML}
        <h2>1. Login Bypass (SQL Injection)</h2>
        <form action="/sqli" method="POST">
            <div class="form-group">
                <label>பாதுகாப்பு நிலை:</label>
                <select name="security"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select>
            </div>
            <div class="form-group">
                <label>பயனர் பெயர்:</label>
                <input type="text" name="username" value="' OR '1'='1">
            </div>
            <div class="form-group">
                <label>கடவுச்சொல்:</label>
                <input type="password" name="password" value="anypass">
            </div>
            <button type="submit">உள்நுழை</button>
        </form>
    ${footerHTML}`;
    res.send(html);
});

app.post('/sqli', (req, res) => {
    const { username, password, security } = req.body;
    let message = "தவறான விபரங்கள்!";
    
    if (security === 'low' && (username.includes("' OR '1'='1") || password.includes("' OR '1'='1"))) {
        message = `💥 Breach Successful!\nவரவேற்கிறோம்: ${db.users[0].username}\nகணக்கு இருப்பு: ₹${db.users[0].balance}`;
    } else if (security === 'medium' && username.replace(/\s+/g, '').includes("'OR'1'='1")) {
        message = `💥 Medium Bypass Successful!\nபயனர்: ${db.users[0].username}`;
    } else {
        const user = db.users.find(u => u.username === username && u.password === password);
        if (user) message = `வெற்றிகரமான லாகின்! பயனர்: ${user.username}`;
    }
    
    res.send(`${headerHTML}<h2>முடிவு (SQLi Result)</h2><div class="result-box">${message}</div>${footerHTML}`);
});

// 3. XSS பக்கம்
app.get('/xss', (req, res) => {
    let html = `${headerHTML}
        <h2>2. Cross-Site Scripting (XSS)</h2>
        <form action="/xss" method="POST">
            <div class="form-group">
                <label>பாதுகாப்பு நிலை:</label>
                <select name="security"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select>
            </div>
            <div class="form-group">
                <label>வங்கி கருத்துரை (Feedback):</label>
                <input type="text" name="comment" value="<script>alert('Hacked')</script>">
            </div>
            <button type="submit">சமர்ப்பி</button>
        </form>
    ${footerHTML}`;
    res.send(html);
});

app.post('/xss', (req, res) => {
    const { comment, security } = req.body;
    let output = comment;

    if (security === 'medium') {
        output = comment.replace(/<script>/gi, '').replace(/<\/script>/gi, '');
    } else if (security === 'high') {
        output = comment.replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    // Low நிலையில் உள்ளீடு அப்படியே பிரவுசரில் HTML ஆக மாறும் (Vulnerable)
    res.send(`${headerHTML}<h2>வங்கி கருத்துப் பக்கம்</h2><h3>பயனர் கருத்து:</h3><div>${output}</div>${footerHTML}`);
});

// 4. IDOR பக்கம்
app.get('/idor', (req, res) => {
    let html = `${headerHTML}
        <h2>3. IDOR (Broken Access Control)</h2>
        <form action="/idor-view" method="GET">
            <div class="form-group">
                <label>பாதுகாப்பு நிலை:</label>
                <select name="security"><option value="low">Low</option><option value="high">High</option></select>
            </div>
            <div class="form-group">
                <label>பார்க்க வேண்டிய கணக்கு எண் (உதாரணம் Kumar ID: 1002):</label>
                <input type="text" name="accountId" value="1002">
            </div>
            <button type="submit">விபரங்களை எடு</button>
        </form>
    ${footerHTML}`;
    res.send(html);
});

app.get('/idor-view', (req, res) => {
    const { accountId, security } = req.query;
    const currentUser = 1001; // லாகின் செய்த பயனர் 'admin'
    let message = "கணக்கு விபரம் இல்லை.";

    if (security === 'low') {
        const account = db.users.find(u => u.id == accountId);
        if (account) message = `🔓 IDOR Breach!\nபெயர்: ${account.username}\nஇருப்பு: ₹${account.balance}`;
    } else {
        if (accountId == currentUser) {
            const account = db.users.find(u => u.id == accountId);
            message = `உங்களது கணக்கு இருப்பு: ₹${account.balance}`;
        } else {
            message = `❌ அணுகல் மறுக்கப்பட்டது! நீங்கள் அடுத்தவர் கணக்கை பார்க்க முடியாது.`;
        }
    }
    res.send(`${headerHTML}<h2>கணக்கு விபரம்</h2><div class="result-box">${message}</div>${footerHTML}`);
});

// 5. Price Tampering பக்கம்
app.get('/tampering', (req, res) => {
    let html = `${headerHTML}
        <h2>4. Price Tampering (விலை மாற்றுதல்)</h2>
        <form action="/checkout" method="POST">
            <div class="form-group">
                <label>பாதுகாப்பு நிலை:</label>
                <select name="security"><option value="low">Low</option><option value="high">High</option></select>
            </div>
            <p><strong>திட்டம்:</strong> Premium Wealth Plan (உண்மை விலை: ₹50,000)</p>
            <input type="hidden" name="planId" value="wealth_plan">
            <div class="form-group">
                <label>செலுத்தப் போகும் விலை (Tampered Price):</label>
                <input type="text" name="price" value="1">
            </div>
            <button type="submit">ஆர்டர் செய்</button>
        </form>
    ${footerHTML}`;
    res.send(html);
});

app.post('/checkout', (req, res) => {
    const { planId, price, security } = req.body;
    let message = "";

    if (security === 'low') {
        message = `💰 Price Tampered Success!\n₹50,000 பிளான் வெறும் ₹${price} ரூபாய்க்கு வாங்கப்பட்டது!`;
    } else {
        const prod = db.products.find(p => p.id === planId);
        if (price == prod.price) {
            message = "ஆர்டர் வெற்றிகரமாக முடிந்தது (₹50,000).";
        } else {
            message = `❌ பாதுகாப்பு எச்சரிக்கை: கள்ளத்தனமாக விலை மாற்றப்பட்டுள்ளது! உண்மை விலை: ₹${prod.price}`;
        }
    }
    res.send(`${headerHTML}<h2>ஆர்டர் நிலை</h2><div class="result-box">${message}</div>${footerHTML}`);
});

// 6. Command Injection பக்கம்
app.get('/cmd', (req, res) => {
    let html = `${headerHTML}
        <h2>5. Command Injection (OS Execution)</h2>
        <form action="/ping" method="GET">
            <div class="form-group">
                <label>பாதுகாப்பு நிலை:</label>
                <select name="security"><option value="low">Low</option><option value="high">High</option></select>
            </div>
            <div class="form-group">
                <label>IP முகவரி (Ping Server):</label>
                <input type="text" name="ip" value="8.8.8.8 && whoami">
            </div>
            <button type="submit">Ping செய்</button>
        </form>
    ${footerHTML}`;
    res.send(html);
});

app.get('/ping', (req, res) => {
    const { ip, security } = req.query;

    if (security === 'low') {
        // விண்டோஸ் மற்றும் லினக்ஸ் இரண்டிற்கும் பொருந்தும் வகையில் 'ping'
        exec(`ping -c 1 ${ip} || ping -n 1 ${ip}`, (err, stdout) => {
            res.send(`${headerHTML}<h2>Ping Result (Low)</h2><div class="result-box">${stdout || err}</div>${footerHTML}`);
        });
    } else {
        const regex = /^([0-9]{1,3}\.){3}[0-9]{1,3}$/;
        if (regex.test(ip)) {
            exec(`ping -c 1 ${ip} || ping -n 1 ${ip}`, (err, stdout) => {
                res.send(`${headerHTML}<h2>Ping Result (High)</h2><div class="result-box">${stdout}</div>${footerHTML}`);
            });
        } else {
            res.send(`${headerHTML}<h2>பாதுகாப்பு தடுப்பு</h2><div class="result-box">❌ ஆபத்தான கட்டளை கண்டறியப்பட்டது!</div>${footerHTML}`);
        }
    }
});

// 7. JWT None Algorithm பக்கம்
app.get('/jwt', (req, res) => {
    let html = `${headerHTML}
        <h2>6. JWT Algorithm None</h2>
        <form action="/jwt" method="POST">
            <div class="form-group">
                <label>பாதுகாப்பு நிலை:</label>
                <select name="security"><option value="low">Low</option><option value="high">High</option></select>
            </div>
            <div class="form-group">
                <label>JWT Algorithm:</label>
                <input type="text" name="alg" value="none">
            </div>
            <div class="form-group">
                <label>Role:</label>
                <input type="text" name="role" value="admin">
            </div>
            <button type="submit">அங்கீகரி (Authenticate)</button>
        </form>
    ${footerHTML}`;
    res.send(html);
});

app.post('/jwt', (req, res) => {
    const { alg, role, security } = req.body;
    let message = "சாதாரண பயனர் கணக்கு.";

    if (security === 'low' && alg === 'none' && role === 'admin') {
        message = "🔓 Privilege Escalation Success! அல்காரிதம் ஏதுமில்லாமல் அட்மின் அனுமதி வழங்கப்பட்டது.";
    } else if (security === 'high') {
        message = "❌ டோக்கன் நிராகரிக்கப்பட்டது! 'none' அல்காரிதம் மற்றும் முறையான கையொப்பம் இல்லாததால் அனுமதி இல்லை.";
    }
    res.send(`${headerHTML}<h2>அணுகல் நிலை</h2><div class="result-box">${message}</div>${footerHTML}`);
});

// 8. SSRF பக்கம்
app.get('/ssrf', (req, res) => {
    let html = `${headerHTML}
        <h2>7. Server-Side Request Forgery (SSRF)</h2>
        <form action="/ssrf" method="POST">
            <div class="form-group">
                <label>பாதுகாப்பு நிலை:</label>
                <select name="security"><option value="low">Low</option><option value="high">High</option></select>
            </div>
            <div class="form-group">
                <label>அவதார் படத்திற்கான URL முகவரி:</label>
                <input type="text" name="url" value="http://127.0.0.1:8080/internal-admin">
            </div>
            <button type="submit">படத்தை பதிவிறக்கு</button>
        </form>
    ${footerHTML}`;
    res.send(html);
});

app.post('/ssrf', (req, res) => {
    const { url, security } = req.body;
    let message = "";

    if (security === 'low') {
        message = `⚠️ SSRF வல்னரபிலிட்டி உருவகப்படுத்தப்பட்டது!\nசர்வர் தனது சொந்த அகநிலைப் பக்கத்தை (Internal Loopback) அழைக்கிறது: ${url}`;
    } else {
        if (url.includes('127.0.0.1') || url.includes('localhost')) {
            message = "❌ பாதுகாப்பு தடுப்பு: உள்ளூர் சர்வர் முகவரிகளை (Localhost) அழைக்க அனுமதியில்லை!";
        } else {
            message = `வெளிப்புறப் படம் பாதுகாப்பாக அழைக்கப்படுகிறது: ${url}`;
        }
    }
    res.send(`${headerHTML}<h2>SSRF நிலை</h2><div class="result-box">${message}</div>${footerHTML}`);
});

app.listen(port, () => console.log(`சர்வர் இயங்குகிறது: http://localhost:${port}`));                                                 